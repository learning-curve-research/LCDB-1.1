export NAME=lcdb11container

